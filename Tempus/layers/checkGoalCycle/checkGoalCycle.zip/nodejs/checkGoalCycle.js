// Utility function to check and reset a goal's cycle if needed
const checkAndResetGoalCycle = async (pool, goal) => {
  if (!goal.is_cycling || !goal.current_cycle_end) {
    return goal; // Not a cycling goal, return as-is
  }

  const today = new Date();
  const todayStr = today.toISOString().split('T')[0];
  const cycleEndDate = new Date(goal.current_cycle_end);
  const dayOfWeek = today.getDay(); // 0=Sunday, 1=Monday, etc.

  // Check if the current cycle has ended
  let shouldReset = false;
  let newCycleStart = todayStr;
  let newCycleEnd = null;

  if (goal.goal_type === 'daily') {
    // For daily goals, reset if today is a selected day and we've passed the cycle end
    const selectedDays = goal.goal_selected_days || [0,1,2,3,4,5,6]; // Default to all days
    const needsReset = today >= cycleEndDate && selectedDays.includes(dayOfWeek);
    
    if (needsReset) {
      shouldReset = true;
      newCycleEnd = todayStr; // Daily cycle ends same day
    }
    
  } else if (goal.goal_type === 'weekly') {
    // Weekly goals reset if we've passed the cycle end date
    if (today > cycleEndDate) {
      shouldReset = true;
      
      // Calculate new weekly cycle based on goal_start_date and cycle_duration
      const startDate = new Date(goal.goal_start_date);
      const completedCycles = (goal.cycles_completed || 0) + 1;
      const cycleDuration = goal.goal_cycle_duration || 1; // Default to 1 week if not specified
      
      const cycleStartDate = new Date(startDate);
      cycleStartDate.setDate(startDate.getDate() + (completedCycles * 7 * cycleDuration));
      
      const cycleEndDate = new Date(cycleStartDate);
      cycleEndDate.setDate(cycleStartDate.getDate() + (7 * cycleDuration) - 1);
      
      newCycleStart = cycleStartDate.toISOString().split('T')[0];
      newCycleEnd = cycleEndDate.toISOString().split('T')[0];
    }
    
  } else if (goal.goal_type === 'monthly') {
    // Monthly goals reset if we've passed the cycle end date
    if (today > cycleEndDate) {
      shouldReset = true;
      
      // Calculate new monthly cycle based on goal_start_date and cycle_duration
      const startDate = new Date(goal.goal_start_date);
      const completedCycles = (goal.cycles_completed || 0) + 1;
      const cycleDuration = goal.goal_cycle_duration || 1; // Default to 1 month if not specified
      
      const cycleStartDate = new Date(startDate);
      cycleStartDate.setMonth(startDate.getMonth() + (completedCycles * cycleDuration));
      
      const cycleEndDate = new Date(cycleStartDate);
      cycleEndDate.setMonth(cycleEndDate.getMonth() + cycleDuration);
      cycleEndDate.setDate(cycleEndDate.getDate() - 1);
      
      newCycleStart = cycleStartDate.toISOString().split('T')[0];
      newCycleEnd = cycleEndDate.toISOString().split('T')[0];
    }
  }

  if (shouldReset) {
    console.log(`[CheckGoalCycle] Resetting goal ${goal.goal_id} (${goal.goal_name})`);
    
    // Reset the goal progress and update cycle dates
    const updateQuery = `
      UPDATE goals 
      SET goal_progress = 0,
          current_cycle_start = $2,
          current_cycle_end = $3,
          cycles_completed = COALESCE(cycles_completed, 0) + 1,
          is_completed = false
      WHERE goal_id = $1
      RETURNING *
    `;
    
    const result = await pool.query(updateQuery, [
      goal.goal_id,
      newCycleStart,
      newCycleEnd
    ]);
    
    console.log(`[CheckGoalCycle] Successfully reset goal ${goal.goal_id}`);
    return result.rows[0]; // Return the updated goal
  }

  return goal; // No reset needed
};

module.exports = { checkAndResetGoalCycle };